# OrderFillTrainer Fun Training Features

Import project.godot in Godot 4.x.

Added:
- Faster PE
- More slots/picks
- 3 AI orderfillers moving around
- Collision penalty with AI traffic
- 3-minute order timer
- Combo bonus
- Parking/stop-zone bonus
- Accuracy + rank feedback after order
- Training tip text
- Existing warehouse roof, picker body, pattern callout training kept


## GitHub APK Build

This repo includes a GitHub Actions workflow:

`.github/workflows/build-apk.yml`

It is named:

`Build APK Factory`

To build:
1. Upload all files in this ZIP to your GitHub repo.
2. Go to GitHub → Actions.
3. Tap **Build APK Factory**.
4. Tap **Run workflow**.
5. After it finishes, download the APK from **Artifacts**.

The APK artifact name is:

`orderfill-trainer-debug-apk`

This is a debug APK for testing on Android.
