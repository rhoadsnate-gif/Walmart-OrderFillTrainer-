
extends Node3D

enum GameState { DRIVING, SLOT_SCREEN }

var state: GameState = GameState.DRIVING

var pe: CharacterBody3D
var pe_visual: Node3D
var camera: Camera3D

var dragging: bool = false
var touch_start: Vector2 = Vector2.ZERO
var move_dir: Vector2 = Vector2.ZERO

var speed: float = 9.2
var reverse_speed: float = 4.0
var turn_speed: float = 2.25

var current_slot_index: int = 0
var near_slot: bool = false
var score: int = 0
var mistakes: int = 0
var combo: int = 0
var best_combo: int = 0
var correct_picks: int = 0
var total_answers: int = 0
var order_time_left: float = 180.0
var ai_hit_cooldown: float = 0.0
var last_distance_to_slot: float = 999.0

var slots: Array = [
	{"aisle":"12","slot":"013","full_code":"53872","pattern":[1,3,5],"item":"IBP Beef Case","pick":1,"pos":Vector3(-4.45,0.05,14.0)},
	{"aisle":"12","slot":"015","full_code":"25814","pattern":[1,3,5],"item":"Boxed Meat Pallet","pick":2,"pos":Vector3(4.45,0.05,6.0)},
	{"aisle":"12","slot":"017","full_code":"74129","pattern":[2,3,5],"item":"Frozen Case Stack","pick":3,"pos":Vector3(-4.45,0.05,-2.0)},
	{"aisle":"12","slot":"019","full_code":"86431","pattern":[1,4,5],"item":"Paper Goods Pallet","pick":4,"pos":Vector3(4.45,0.05,-10.0)},
	{"aisle":"12","slot":"021","full_code":"34927","pattern":[2,4,5],"item":"Wrapped Pallet","pick":5,"pos":Vector3(-4.45,0.05,-18.0)},
	{"aisle":"12","slot":"023","full_code":"92568","pattern":[1,2,5],"item":"Dairy Case Pallet","pick":6,"pos":Vector3(4.45,0.05,-26.0)},
	{"aisle":"12","slot":"025","full_code":"61793","pattern":[1,4,5],"item":"Case Pick Stack","pick":7,"pos":Vector3(-4.45,0.05,-34.0)},
	{"aisle":"12","slot":"027","full_code":"48216","pattern":[2,3,5],"item":"Multi Slot Pick","pick":8,"pos":Vector3(4.45,0.05,18.0)}
]

var slot_markers: Array = []
var ai_orderfillers: Array = []
var picker_body: Node3D
var picker_timer: float = 0.0
var answer_buttons: Array = []

var hud_layer: CanvasLayer
var top_label: Label
var status_label: Label
var pick_button: Button
var slot_panel: Panel
var slot_title: Label
var slot_code_label: Label
var callout_label: Label
var feedback_label: Label
var training_tip_label: Label
var stop_zone_label: Label
var slot_photo_view: Control
var confirm_button: Button
var back_button: Button
var drive_pad: Control

func _ready() -> void:
	randomize()
	make_world()
	make_warehouse_aisle()
	make_warehouse_roof()
	make_slots()
	make_ai_orderfillers()
	make_pe()
	make_camera()
	make_hud()
	update_hud()

func _physics_process(delta: float) -> void:
	if state == GameState.DRIVING:
		update_pe_movement(delta)
		check_slot_distance()
	update_training_timer(delta)
	update_ai_orderfillers(delta)
	check_ai_collision(delta)
	update_picker_body(delta)
	update_camera(delta)

func update_pe_movement(delta: float) -> void:
	if pe == null:
		return

	var forward_amount: float = 0.0
	var turn_amount: float = 0.0

	if dragging:
		# This matches your tested-good controls:
		# finger up/down works, side-to-side is flipped correctly from previous final build.
		forward_amount = float(clamp(move_dir.y * 0.045, -reverse_speed, speed))
		turn_amount = float(clamp(-move_dir.x * 0.0032, -0.75, 0.75))

	if abs(forward_amount) > 0.05:
		pe.rotation.y += turn_amount * turn_speed * delta

	var front_direction: Vector3 = pe.global_transform.basis.z
	pe.velocity = front_direction * forward_amount
	pe.move_and_slide()

func check_slot_distance() -> void:
	if current_slot_index >= slots.size():
		return

	var slot: Dictionary = slots[current_slot_index]
	var slot_pos: Vector3 = slot["pos"]
	var dist: float = pe.global_position.distance_to(slot_pos)
	last_distance_to_slot = dist
	near_slot = dist < 2.25

	if near_slot:
		status_label.text = "STOP ZONE - tap PICK when lined up"
	else:
		status_label.text = "Drive to glowing blue slot " + str(slot["slot"]) + "   Distance: " + str(snapped(dist, 0.1))

	pick_button.disabled = not near_slot

func get_callout(full_number: String, pattern: Array) -> String:
	var result := ""
	for p in pattern:
		var index: int = int(p) - 1
		if index >= 0 and index < full_number.length():
			result += full_number[index]
	return result

func pattern_to_text(pattern: Array) -> String:
	var text := ""
	for i in range(pattern.size()):
		if i > 0:
			text += "-"
		text += str(pattern[i])
	return text

func make_wrong_answer(correct: String) -> String:
	var wrong := correct
	while wrong == correct:
		wrong = ""
		for i in range(3):
			wrong += str(randi() % 10)
	return wrong


func update_training_timer(delta: float) -> void:
	if state != GameState.DRIVING:
		return

	order_time_left -= delta
	if order_time_left <= 0.0:
		score -= 100
		mistakes += 1
		combo = 0
		order_time_left = 180.0
		status_label.text = "Time ran out - new order started"
		reset_order()
		return

	update_hud()

func check_ai_collision(delta: float) -> void:
	if ai_hit_cooldown > 0.0:
		ai_hit_cooldown -= delta
		return

	if pe == null:
		return

	for ai in ai_orderfillers:
		var n: Node3D = ai["node"]
		if pe.global_position.distance_to(n.global_position) < 1.25:
			score -= 75
			mistakes += 1
			combo = 0
			ai_hit_cooldown = 2.0
			status_label.text = "Watch traffic! -75"
			update_hud()
			return

func parking_bonus() -> int:
	# Rewards stopping close to the rack/slot instead of just tapping PICK anywhere in range.
	if last_distance_to_slot <= 0.85:
		return 50
	if last_distance_to_slot <= 1.35:
		return 25
	return 0

func accuracy_text() -> String:
	if total_answers <= 0:
		return "100%"
	var acc: float = float(correct_picks) / float(total_answers) * 100.0
	return str(int(acc)) + "%"

func rank_text() -> String:
	if score >= 900 and mistakes == 0:
		return "GOLD ORDERFILLER"
	if score >= 600:
		return "SILVER ORDERFILLER"
	if score >= 300:
		return "BRONZE ORDERFILLER"
	return "TRAINING RUN"


func start_slot_screen() -> void:
	if current_slot_index >= slots.size():
		return

	state = GameState.SLOT_SCREEN
	dragging = false
	move_dir = Vector2.ZERO
	pe.velocity = Vector3.ZERO

	var slot: Dictionary = slots[current_slot_index]
	var full_number: String = str(slot["full_code"])
	var pattern: Array = slot["pattern"]
	var correct: String = get_callout(full_number, pattern)

	slot_title.text = "AISLE " + str(slot["aisle"]) + "   SLOT " + str(slot["slot"])
	slot_code_label.text = "FULL: " + full_number + "     PATTERN: " + pattern_to_text(pattern)
	callout_label.text = "CHOOSE 3-DIGIT CALLOUT"

	build_generated_slot_photo(slot)
	show_picker_action_at_current_slot()

	var choices: Array = [correct]
	while choices.size() < 4:
		var fake := make_wrong_answer(correct)
		if not choices.has(fake):
			choices.append(fake)
	choices.shuffle()

	for i in range(answer_buttons.size()):
		var b: Button = answer_buttons[i]
		b.text = str(choices[i])
		b.disabled = false
		for c in b.pressed.get_connections():
			b.pressed.disconnect(c.callable)
		b.pressed.connect(confirm_slot.bind(str(choices[i]), correct))

	feedback_label.text = "Park bonus: +" + str(parking_bonus()) + " if answer is correct"
	slot_panel.visible = true
	pick_button.visible = false
	status_label.visible = false
	update_hud()

func confirm_slot(selected_answer: String = "", correct_answer: String = "") -> void:
	total_answers += 1

	if selected_answer == correct_answer:
		correct_picks += 1
		combo += 1
		best_combo = max(best_combo, combo)

		var park_bonus: int = parking_bonus()
		var combo_bonus: int = min(combo * 10, 50)
		var gained: int = 100 + park_bonus + combo_bonus
		score += gained

		if feedback_label:
			feedback_label.text = "CORRECT +" + str(gained) + "   Combo x" + str(combo)
	else:
		mistakes += 1
		combo = 0
		score -= 75
		if feedback_label:
			feedback_label.text = "WRONG -75   Correct: " + correct_answer

	for b in answer_buttons:
		b.disabled = true

	await get_tree().create_timer(1.05).timeout

	clear_generated_slot_photo()
	slot_panel.visible = false
	pick_button.visible = true
	status_label.visible = true

	current_slot_index += 1

	if current_slot_index >= slots.size():
		reset_order()
	else:
		state = GameState.DRIVING
		update_slot_markers()
		update_hud()

func close_slot_screen() -> void:
	clear_generated_slot_photo()
	state = GameState.DRIVING
	slot_panel.visible = false
	pick_button.visible = true
	status_label.visible = true
	update_hud()

func reset_order() -> void:
	current_slot_index = 0
	state = GameState.DRIVING
	dragging = false
	move_dir = Vector2.ZERO

	if pe:
		pe.global_position = Vector3(0, 0.0, 32)
		pe.rotation_degrees.y = 0.0
		pe.velocity = Vector3.ZERO

	slot_panel.visible = false
	pick_button.visible = true
	status_label.visible = true
	order_time_left = 180.0
	status_label.text = rank_text() + "  Score " + str(score) + "  Accuracy " + accuracy_text()
	update_slot_markers()
	update_hud()

func update_hud() -> void:
	if top_label == null:
		return
	var index: int = min(current_slot_index, slots.size() - 1)
	var slot: Dictionary = slots[index]
	top_label.text = "ORDER #1024     AISLE " + str(slot["aisle"]) + "     SLOT " + str(slot["slot"]) + "     PICK " + str(slot["pick"]) + "     ITEM " + str(slot["item"]) + "     PICKS " + str(current_slot_index) + "/" + str(slots.size()) + "     SCORE " + str(score) + "     TIME " + str(int(order_time_left)) + "     COMBO " + str(combo)

func update_camera(delta: float) -> void:
	if camera == null or pe == null:
		return

	if state == GameState.DRIVING:
		# Camera view that worked: shows forks/boxes side.
		var front_direction: Vector3 = pe.global_transform.basis.z
		var back_direction: Vector3 = -front_direction
		var wanted: Vector3 = pe.global_position + front_direction * 11.5 + Vector3(0, 6.5, 0)
		camera.global_position = camera.global_position.lerp(wanted, 5.0 * delta)
		camera.look_at(pe.global_position + back_direction * 12.0 + Vector3(0, 1.2, 0), Vector3.UP)

	if state == GameState.SLOT_SCREEN:
		var slot: Dictionary = slots[current_slot_index]
		var slot_pos: Vector3 = slot["pos"]
		var wanted_slot_pos: Vector3 = slot_pos + Vector3(0, 2.1, 3.2)
		camera.global_position = camera.global_position.lerp(wanted_slot_pos, 5.0 * delta)
		camera.look_at(slot_pos + Vector3(0, 1.15, 0), Vector3.UP)

func _on_drive_pad_gui_input(event: InputEvent) -> void:
	if state != GameState.DRIVING:
		return

	if event is InputEventScreenTouch:
		dragging = event.pressed
		touch_start = event.position
		if not event.pressed:
			move_dir = Vector2.ZERO

	if event is InputEventScreenDrag:
		move_dir = event.position - touch_start

func make_world() -> void:
	var env_node := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.035, 0.035, 0.038)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.58, 0.58, 0.55)
	env.ambient_light_energy = 1.15
	env_node.environment = env
	add_child(env_node)

	var sun := DirectionalLight3D.new()
	sun.name = "Warehouse_Directional_Light"
	sun.light_energy = 2.9
	sun.rotation_degrees = Vector3(-70, 28, 0)
	add_child(sun)

	for z in range(-34, 35, 8):
		var light := OmniLight3D.new()
		light.name = "Ceiling_Light"
		light.light_energy = 2.25
		light.omni_range = 14.0
		light.position = Vector3(0, 7.0, z)
		add_child(light)

func make_warehouse_aisle() -> void:
	var floor := MeshInstance3D.new()
	floor.name = "Polished_Concrete_Floor"
	var pm := PlaneMesh.new()
	pm.size = Vector2(18, 78)
	floor.mesh = pm
	floor.material_override = mat(Color(0.31, 0.30, 0.27), 0.88)
	add_child(floor)

	var static_floor := StaticBody3D.new()
	static_floor.name = "Floor_Collision"
	add_child(static_floor)

	var col := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(18, 0.2, 78)
	col.shape = box
	col.position.y = -0.1
	static_floor.add_child(col)

	for z in range(-36, 37, 6):
		add_child(mesh_box(Vector3(17.5, 0.018, 0.035), Color(0.18, 0.18, 0.17), Vector3(0, 0.025, z)))

	for x in [-5.05, 5.05]:
		add_child(mesh_box(Vector3(0.08, 0.025, 74), Color(0.88, 0.62, 0.05), Vector3(x, 0.028, 0)))

	for side in [-1, 1]:
		for z in range(-34, 35, 4):
			make_rack_section(Vector3(side * 6.25, 0, z), side)
		make_aisle_sign(Vector3(side * 4.75, 2.05, 8), "12")
		make_aisle_sign(Vector3(side * 4.75, 2.05, -14), "12")

func make_rack_section(pos: Vector3, side: int) -> void:
	var root := Node3D.new()
	root.name = "Tall_Rack_Section"
	root.position = pos
	add_child(root)

	for x in [-1.4, 1.4]:
		for z in [-0.9, 0.9]:
			root.add_child(mesh_box(Vector3(0.12, 5.4, 0.12), Color(0.24, 0.25, 0.25), Vector3(x, 2.7, z)))

	for y in [0.75, 1.65, 2.55, 3.45, 4.35, 5.15]:
		root.add_child(mesh_box(Vector3(3.1, 0.11, 0.13), Color(0.86, 0.25, 0.04), Vector3(0, y, -0.9)))
		root.add_child(mesh_box(Vector3(3.1, 0.11, 0.13), Color(0.86, 0.25, 0.04), Vector3(0, y, 0.9)))

	for flip in [-1, 1]:
		var brace := mesh_box(Vector3(0.07, 3.0, 0.07), Color(0.23, 0.24, 0.24), Vector3(flip * 0.75, 2.5, side * 0.95))
		brace.rotation_degrees.z = 28 * flip
		root.add_child(brace)

	for level in range(5):
		var ybase: float = 0.18 + level * 0.9
		for slot_x in [-0.82, 0.0, 0.82]:
			root.add_child(mesh_box(Vector3(0.75, 0.12, 0.75), Color(0.0, 0.20, 0.52), Vector3(slot_x, ybase, side * 0.35)))
			var package_color: Color = Color(0.60, 0.43, 0.25) if level % 2 == 0 else Color(0.78, 0.78, 0.74)
			for stack in range(2):
				root.add_child(mesh_box(Vector3(0.62, 0.35, 0.58), package_color, Vector3(slot_x, ybase + 0.24 + stack * 0.36, side * 0.35)))

	for zedge in [-1.0, 1.0]:
		root.add_child(mesh_box(Vector3(0.23, 0.75, 0.23), Color(0.95, 0.70, 0.02), Vector3(-side * 1.42, 0.38, zedge)))

func make_aisle_sign(pos: Vector3, aisle_text: String) -> void:
	var sign := mesh_box(Vector3(1.65, 0.08, 1.05), Color(0.02, 0.12, 0.36), pos)
	sign.name = "Aisle_" + aisle_text + "_Sign"
	sign.rotation_degrees.y = 90
	add_child(sign)


func make_warehouse_roof() -> void:
	# Ceiling panels, beams, and lights so the top is not bare black.
	var ceiling := Node3D.new()
	ceiling.name = "Warehouse_Roof_Ceiling"
	add_child(ceiling)

	# Large dim ceiling sheets
	for z in range(-36, 37, 8):
		var panel := mesh_box(Vector3(17.5, 0.08, 7.4), Color(0.20, 0.21, 0.22), Vector3(0, 7.8, z))
		ceiling.add_child(panel)

	# Cross beams
	for z in range(-38, 39, 4):
		ceiling.add_child(mesh_box(Vector3(18.0, 0.14, 0.12), Color(0.10, 0.11, 0.12), Vector3(0, 7.55, z)))

	# Long roof rails
	for x in [-7.5, -3.75, 0, 3.75, 7.5]:
		ceiling.add_child(mesh_box(Vector3(0.12, 0.16, 78), Color(0.11, 0.12, 0.13), Vector3(x, 7.45, 0)))

	# Bright hanging light bars
	for z in range(-32, 33, 8):
		var light_bar := mesh_box(Vector3(1.7, 0.08, 0.22), Color(0.92, 0.93, 0.86), Vector3(0, 7.25, z))
		ceiling.add_child(light_bar)

func make_ai_orderfillers() -> void:
	# Other orderfillers moving slowly in the aisle for a real training feel.
	var ai1 := make_ai_pe("AI_Orderfiller_1", Vector3(-2.8, 0.0, -4.0), 0.0)
	add_child(ai1)
	ai_orderfillers.append({"node": ai1, "base_x": -2.8, "z_min": -26.0, "z_max": 10.0, "speed": 2.0, "dir": 1.0})

	var ai2 := make_ai_pe("AI_Orderfiller_2", Vector3(2.8, 0.0, -18.0), 180.0)
	add_child(ai2)
	ai_orderfillers.append({"node": ai2, "base_x": 2.8, "z_min": -30.0, "z_max": 6.0, "speed": 1.65, "dir": -1.0})

	var ai3 := make_ai_pe("AI_Orderfiller_3", Vector3(0.0, 0.0, -28.0), 0.0)
	add_child(ai3)
	ai_orderfillers.append({"node": ai3, "base_x": 0.0, "z_min": -34.0, "z_max": -8.0, "speed": 2.4, "dir": 1.0})

func make_ai_pe(name_text: String, pos: Vector3, rot_y: float) -> Node3D:
	var root := Node3D.new()
	root.name = name_text
	root.position = pos
	root.rotation_degrees.y = rot_y

	root.add_child(mesh_box(Vector3(1.1, 0.55, 0.85), Color(0.70, 0.66, 0.56), Vector3(0, 0.45, -0.25)))
	root.add_child(mesh_box(Vector3(1.15, 0.18, 0.9), Color(0.02, 0.02, 0.025), Vector3(0, 0.18, -0.25)))
	root.add_child(mesh_box(Vector3(0.80, 0.14, 0.28), Color(0.95, 0.42, 0.02), Vector3(0, 0.82, -0.75)))
	root.add_child(mesh_box(Vector3(0.06, 0.60, 0.06), Color(0.01, 0.01, 0.01), Vector3(-0.45, 1.05, -0.75)))
	root.add_child(mesh_box(Vector3(0.06, 0.60, 0.06), Color(0.01, 0.01, 0.01), Vector3(0.45, 1.05, -0.75)))

	for x in [-0.25, 0.25]:
		root.add_child(mesh_box(Vector3(0.12, 0.08, 1.6), Color(0.015, 0.015, 0.018), Vector3(x, 0.08, 0.9)))

	root.add_child(mesh_box(Vector3(1.25, 0.12, 0.95), Color(0.0, 0.20, 0.55), Vector3(0, 0.23, 0.88)))
	for i in range(3):
		root.add_child(mesh_box(Vector3(0.32, 0.28, 0.32), Color(0.60, 0.42, 0.24), Vector3(-0.35 + i * 0.35, 0.47, 0.75)))

	# Simple human/operator shape
	root.add_child(mesh_cylinder(0.16, 0.55, Color(0.08, 0.08, 0.09), Vector3(0, 1.25, -0.45), Vector3(0, 0, 0)))
	root.add_child(mesh_cylinder(0.14, 0.14, Color(0.78, 0.58, 0.42), Vector3(0, 1.62, -0.45), Vector3(0, 0, 0)))
	return root

func update_ai_orderfillers(delta: float) -> void:
	for ai in ai_orderfillers:
		var n: Node3D = ai["node"]
		var dir: float = ai["dir"]
		n.position.z += dir * float(ai["speed"]) * delta
		n.position.x = float(ai["base_x"])

		if n.position.z > float(ai["z_max"]):
			ai["dir"] = -1.0
			n.rotation_degrees.y = 180.0
		elif n.position.z < float(ai["z_min"]):
			ai["dir"] = 1.0
			n.rotation_degrees.y = 0.0

func make_picker_body() -> Node3D:
	var root := Node3D.new()
	root.name = "Picker_Body_Getting_Box"
	root.visible = false
	add_child(root)

	root.add_child(mesh_cylinder(0.16, 0.75, Color(0.08, 0.10, 0.12), Vector3(0, 0.82, 0), Vector3(0, 0, 0)))
	root.add_child(mesh_cylinder(0.18, 0.18, Color(0.78, 0.58, 0.42), Vector3(0, 1.30, 0), Vector3(0, 0, 0)))
	root.add_child(mesh_box(Vector3(0.16, 0.55, 0.12), Color(0.04, 0.04, 0.045), Vector3(-0.18, 0.28, 0)))
	root.add_child(mesh_box(Vector3(0.16, 0.55, 0.12), Color(0.04, 0.04, 0.045), Vector3(0.18, 0.28, 0)))
	root.add_child(mesh_box(Vector3(0.72, 0.32, 0.45), Color(0.60, 0.42, 0.24), Vector3(0.55, 0.9, 0)))
	return root

func update_picker_body(delta: float) -> void:
	if picker_body == null:
		return

	if picker_timer > 0.0:
		picker_timer -= delta
		picker_body.visible = true
		picker_body.position.y = 0.08 + sin(Time.get_ticks_msec() * 0.012) * 0.04
	else:
		picker_body.visible = false

func show_picker_action_at_current_slot() -> void:
	if picker_body == null:
		picker_body = make_picker_body()

	var slot: Dictionary = slots[min(current_slot_index, slots.size() - 1)]
	var p: Vector3 = slot["pos"]
	picker_body.global_position = p + Vector3(0.55, 0.0, 0.55)
	picker_body.look_at(pe.global_position, Vector3.UP)
	picker_timer = 1.8


func make_slots() -> void:
	for i in range(slots.size()):
		var slot: Dictionary = slots[i]
		var marker := Node3D.new()
		marker.name = "Slot_" + str(slot["slot"])
		marker.position = slot["pos"]
		add_child(marker)
		slot_markers.append(marker)

		marker.add_child(mesh_box(Vector3(1.75, 0.12, 1.1), Color(0.0, 0.18, 0.55), Vector3(0, 0.15, 0)))

		for row in range(3):
			for col_i in range(3):
				marker.add_child(mesh_box(Vector3(0.52, 0.36, 0.42), Color(0.58, 0.39, 0.21), Vector3(-0.55 + col_i * 0.55, 0.40 + row * 0.37, -0.20)))

		marker.add_child(mesh_box(Vector3(2.2, 0.12, 0.18), Color(0.95, 0.28, 0.04), Vector3(0, 1.75, -0.18)))

		var label3d := Label3D.new()
		label3d.name = "Slot_Code_Label"
		label3d.text = "MB " + str(slot["slot"]) + "     " + str(slot["full_code"])
		label3d.font_size = 42
		label3d.modulate = Color(0, 0, 0)
		label3d.position = Vector3(0, 1.9, -0.30)
		label3d.rotation_degrees.x = -15
		marker.add_child(label3d)

	update_slot_markers()

func update_slot_markers() -> void:
	for i in range(slot_markers.size()):
		var marker: Node3D = slot_markers[i]
		if i == current_slot_index:
			marker.scale = Vector3(1.18, 1.18, 1.18)
		else:
			marker.scale = Vector3(1.0, 1.0, 1.0)

func make_pe() -> void:
	pe = CharacterBody3D.new()
	pe.name = "PE"
	pe.position = Vector3(0, 0.0, 32)
	pe.rotation_degrees.y = 0.0
	add_child(pe)

	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(1.9, 1.35, 4.35)
	col.shape = shape
	col.position = Vector3(0, 0.65, 0.9)
	pe.add_child(col)

	pe_visual = Node3D.new()
	pe_visual.name = "PE_Visual"
	pe.add_child(pe_visual)

	pe_visual.add_child(mesh_box(Vector3(1.55, 0.86, 1.12), Color(0.72, 0.67, 0.57), Vector3(0, 0.58, -0.35)))
	pe_visual.add_child(mesh_box(Vector3(1.68, 0.24, 1.20), Color(0.025, 0.025, 0.028), Vector3(0, 0.18, -0.35)))
	pe_visual.add_child(mesh_cylinder(0.15, 0.80, Color(0.92, 0.92, 0.86), Vector3(-0.88, 0.95, -0.55), Vector3(0, 0, 0)))
	pe_visual.add_child(mesh_cylinder(0.15, 0.80, Color(0.92, 0.92, 0.86), Vector3(0.88, 0.95, -0.55), Vector3(0, 0, 0)))
	pe_visual.add_child(mesh_box(Vector3(1.25, 0.24, 1.05), Color(0.02, 0.02, 0.022), Vector3(0, 1.00, -0.80)))
	pe_visual.add_child(mesh_box(Vector3(0.95, 0.18, 0.38), Color(0.95, 0.42, 0.02), Vector3(0, 1.23, -1.05)))
	pe_visual.add_child(mesh_box(Vector3(1.25, 0.08, 0.08), Color(0.01, 0.01, 0.012), Vector3(0, 1.82, -1.00)))
	pe_visual.add_child(mesh_box(Vector3(0.08, 0.82, 0.08), Color(0.01, 0.01, 0.012), Vector3(-0.62, 1.42, -1.00)))
	pe_visual.add_child(mesh_box(Vector3(0.08, 0.82, 0.08), Color(0.01, 0.01, 0.012), Vector3(0.62, 1.42, -1.00)))
	pe_visual.add_child(mesh_cylinder(0.32, 0.08, Color(0.01, 0.01, 0.012), Vector3(0, 1.32, -1.18), Vector3(90, 0, 0)))

	for x in [-0.42, 0.42]:
		pe_visual.add_child(mesh_box(Vector3(0.18, 0.12, 2.95), Color(0.018, 0.018, 0.022), Vector3(x, 0.08, 1.65)))
		pe_visual.add_child(mesh_box(Vector3(0.28, 0.06, 0.32), Color(0.006, 0.006, 0.008), Vector3(x, 0.06, 3.10)))

	pe_visual.add_child(mesh_box(Vector3(1.85, 0.16, 1.55), Color(0.0, 0.21, 0.55), Vector3(0, 0.27, 1.70)))
	for slat_x in [-0.65, -0.25, 0.25, 0.65]:
		pe_visual.add_child(mesh_box(Vector3(0.10, 0.08, 1.55), Color(0.03, 0.32, 0.65), Vector3(slat_x, 0.40, 1.70)))

	for ix in range(4):
		for iz in range(3):
			pe_visual.add_child(mesh_box(Vector3(0.38, 0.34, 0.36), Color(0.62, 0.43, 0.24), Vector3(-0.58 + ix * 0.38, 0.62, 1.25 + iz * 0.38)))

	for ix in range(3):
		for iz in range(2):
			pe_visual.add_child(mesh_cylinder(0.13, 0.33, Color(0.90, 0.90, 0.86), Vector3(0.58 + ix * 0.19, 0.68, 1.20 + iz * 0.28), Vector3(0, 0, 0)))

func make_camera() -> void:
	camera = Camera3D.new()
	camera.name = "Camera3D"
	camera.fov = 54
	camera.position = Vector3(0, 6.5, 20.5)
	add_child(camera)
	camera.current = true

func make_hud() -> void:
	hud_layer = CanvasLayer.new()
	hud_layer.name = "HUD"
	add_child(hud_layer)

	drive_pad = Control.new()
	drive_pad.name = "Full_Screen_Drive_Pad"
	drive_pad.position = Vector2(0, 0)
	drive_pad.size = Vector2(1280, 720)
	drive_pad.mouse_filter = Control.MOUSE_FILTER_STOP
	drive_pad.gui_input.connect(_on_drive_pad_gui_input)
	hud_layer.add_child(drive_pad)

	var top := Panel.new()
	top.position = Vector2(10, 10)
	top.size = Vector2(1260, 86)
	top.modulate = Color(1, 1, 1, 0.82)
	hud_layer.add_child(top)

	top_label = Label.new()
	top_label.position = Vector2(28, 30)
	top_label.add_theme_font_size_override("font_size", 25)
	hud_layer.add_child(top_label)

	status_label = Label.new()
	status_label.text = "Drive to first slot"
	status_label.position = Vector2(30, 105)
	status_label.add_theme_font_size_override("font_size", 24)
	hud_layer.add_child(status_label)

	training_tip_label = Label.new()
	training_tip_label.text = "Training: park close, avoid traffic, read pattern, choose callout."
	training_tip_label.position = Vector2(30, 140)
	training_tip_label.add_theme_font_size_override("font_size", 18)
	hud_layer.add_child(training_tip_label)

	pick_button = Button.new()
	pick_button.text = "PICK"
	pick_button.position = Vector2(1065, 610)
	pick_button.size = Vector2(180, 70)
	pick_button.disabled = true
	pick_button.pressed.connect(start_slot_screen)
	hud_layer.add_child(pick_button)

	slot_panel = Panel.new()
	slot_panel.visible = false
	slot_panel.position = Vector2(55, 55)
	slot_panel.size = Vector2(1170, 610)
	hud_layer.add_child(slot_panel)

	var dark_readable_bg := ColorRect.new()
	dark_readable_bg.color = Color(0, 0, 0, 0.86)
	dark_readable_bg.position = Vector2(515, 30)
	dark_readable_bg.size = Vector2(610, 520)
	slot_panel.add_child(dark_readable_bg)

	slot_title = Label.new()
	slot_title.position = Vector2(540, 50)
	slot_title.add_theme_font_size_override("font_size", 46)
	slot_title.add_theme_color_override("font_outline_color", Color.BLACK)
	slot_title.add_theme_constant_override("outline_size", 6)
	slot_panel.add_child(slot_title)

	slot_code_label = Label.new()
	slot_code_label.position = Vector2(540, 120)
	slot_code_label.add_theme_font_size_override("font_size", 38)
	slot_code_label.add_theme_color_override("font_outline_color", Color.BLACK)
	slot_code_label.add_theme_constant_override("outline_size", 6)
	slot_panel.add_child(slot_code_label)

	callout_label = Label.new()
	callout_label.position = Vector2(540, 195)
	callout_label.add_theme_font_size_override("font_size", 64)
	callout_label.add_theme_color_override("font_outline_color", Color.BLACK)
	callout_label.add_theme_constant_override("outline_size", 8)
	slot_panel.add_child(callout_label)

	var help := Label.new()
	help.text = "Read rack label + daily pattern. Correct = combo bonus. Park close = bonus."
	help.position = Vector2(540, 280)
	help.add_theme_font_size_override("font_size", 24)
	slot_panel.add_child(help)

	feedback_label = Label.new()
	feedback_label.text = "Park bonus: +" + str(parking_bonus()) + " if answer is correct"
	feedback_label.position = Vector2(540, 320)
	feedback_label.add_theme_font_size_override("font_size", 34)
	feedback_label.add_theme_color_override("font_outline_color", Color.BLACK)
	feedback_label.add_theme_constant_override("outline_size", 5)
	slot_panel.add_child(feedback_label)

	answer_buttons.clear()
	for i in range(4):
		var ans_btn := Button.new()
		ans_btn.text = "000"
		ans_btn.position = Vector2(540 + (i % 2) * 210, 380 + int(i / 2) * 70)
		ans_btn.size = Vector2(190, 58)
		ans_btn.add_theme_font_size_override("font_size", 30)
		slot_panel.add_child(ans_btn)
		answer_buttons.append(ans_btn)

	slot_photo_view = Control.new()
	slot_photo_view.name = "Generated_Slot_Photo"
	slot_photo_view.position = Vector2(30, 70)
	slot_photo_view.size = Vector2(465, 365)
	slot_panel.add_child(slot_photo_view)

	back_button = Button.new()
	back_button.text = "BACK"
	back_button.position = Vector2(60, 520)
	back_button.size = Vector2(200, 70)
	back_button.pressed.connect(close_slot_screen)
	slot_panel.add_child(back_button)

func clear_generated_slot_photo() -> void:
	if slot_photo_view == null:
		return
	for c in slot_photo_view.get_children():
		c.queue_free()

func build_generated_slot_photo(slot: Dictionary) -> void:
	clear_generated_slot_photo()
	if slot_photo_view == null:
		return

	var bg := ColorRect.new()
	bg.color = Color(0.08, 0.075, 0.07)
	bg.position = Vector2(0, 0)
	bg.size = Vector2(485, 360)
	slot_photo_view.add_child(bg)

	for y in [35, 105, 178]:
		var beam := ColorRect.new()
		beam.color = Color(0.88, 0.28, 0.05)
		beam.position = Vector2(0, y)
		beam.size = Vector2(485, 18)
		slot_photo_view.add_child(beam)

	for x in [18, 135, 260, 420]:
		var post := ColorRect.new()
		post.color = Color(0.18, 0.19, 0.19)
		post.position = Vector2(x, 0)
		post.size = Vector2(12, 360)
		slot_photo_view.add_child(post)

	var white_tag := ColorRect.new()
	white_tag.color = Color(0.92, 0.92, 0.86)
	white_tag.position = Vector2(195, 106)
	white_tag.size = Vector2(145, 46)
	slot_photo_view.add_child(white_tag)

	var tag_text := Label.new()
	tag_text.text = "MB " + str(slot["slot"])
	tag_text.position = Vector2(202, 113)
	tag_text.add_theme_font_size_override("font_size", 16)
	tag_text.modulate = Color(0.02, 0.02, 0.02)
	slot_photo_view.add_child(tag_text)

	var yellow := ColorRect.new()
	yellow.color = Color(0.95, 0.92, 0.10)
	yellow.position = Vector2(270, 106)
	yellow.size = Vector2(92, 46)
	slot_photo_view.add_child(yellow)

	var call := Label.new()
	call.text = str(slot["full_code"])
	call.position = Vector2(276, 112)
	call.add_theme_font_size_override("font_size", 25)
	call.modulate = Color(0.02, 0.02, 0.02)
	slot_photo_view.add_child(call)

	var multi := ColorRect.new()
	multi.color = Color(0.95, 0.86, 0.18)
	multi.position = Vector2(342, 142)
	multi.size = Vector2(95, 28)
	slot_photo_view.add_child(multi)

	var multi_text := Label.new()
	multi_text.text = "Multi Slots"
	multi_text.position = Vector2(350, 147)
	multi_text.add_theme_font_size_override("font_size", 14)
	multi_text.modulate = Color(0.02, 0.02, 0.02)
	slot_photo_view.add_child(multi_text)

	for row in range(4):
		for col in range(4):
			var box := ColorRect.new()
			box.color = Color(0.60, 0.43, 0.25)
			box.position = Vector2(55 + col * 90, 198 + row * 38)
			box.size = Vector2(82, 34)
			slot_photo_view.add_child(box)

			var logo := Label.new()
			logo.text = "ibp   BEEF"
			logo.position = Vector2(62 + col * 90, 205 + row * 38)
			logo.add_theme_font_size_override("font_size", 12)
			logo.modulate = Color(0.02, 0.20, 0.18)
			slot_photo_view.add_child(logo)

func mesh_box(size: Vector3, color: Color, pos: Vector3) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var b := BoxMesh.new()
	b.size = size
	m.mesh = b
	m.position = pos
	m.material_override = mat(color, 0.78)
	return m

func mesh_cylinder(radius: float, height: float, color: Color, pos: Vector3, rot_deg: Vector3) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var c := CylinderMesh.new()
	c.top_radius = radius
	c.bottom_radius = radius
	c.height = height
	c.radial_segments = 32
	m.mesh = c
	m.position = pos
	m.rotation_degrees = rot_deg
	m.material_override = mat(color, 0.68)
	return m

func mat(color: Color, roughness: float) -> StandardMaterial3D:
	var s := StandardMaterial3D.new()
	s.albedo_color = color
	s.roughness = roughness
	return s
